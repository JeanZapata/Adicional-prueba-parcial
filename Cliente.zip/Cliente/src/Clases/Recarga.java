package Clases;

public class Recarga {
    private int idReca;
    private int valor;
    private int saldo;
    private int megas;

    public Recarga(int idReca, int valor, int saldo, int megas) {
        this.idReca = idReca;
        this.valor = valor;
        this.saldo = saldo;
        this.megas = megas;
    }

    public int getIdReca() { return idReca; }
    public int getValor() { return valor; }
    public int getSaldo() { return saldo; }
    public int getMegas() { return megas; }
}