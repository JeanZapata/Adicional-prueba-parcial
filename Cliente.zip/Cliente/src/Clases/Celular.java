package Clases;

public class Celular {
    private int idCel;
    private String numero;
    private int estado; // 1 = activo, 0 = inactivo
    private int saldo;
    private int megas;

    public Celular(int idCel, String numero, int estado) {
        this.idCel = idCel;
        this.numero = numero;
        this.estado = estado;
        this.saldo = 0;
        this.megas = 0;
    }

    public int getIdCel() { return idCel; }
    public String getNumero() { return numero; }
    public int getEstado() { return estado; }
    public int getSaldo() { return saldo; }
    public int getMegas() { return megas; }

    public void setEstado(int estado) { this.estado = estado; }
    public void agregarSaldo(int cantidad) { this.saldo += cantidad; }
    public void agregarMegas(int cantidad) { this.megas += cantidad; }
}