package BaseDatos;

import Clases.Celular;
import Clases.Recarga;
import java.util.ArrayList;

public class BDCelular {
    ArrayList<Celular> listaCelulares = new ArrayList<>();
    ArrayList<Recarga> listaRecargas = new ArrayList<>();
    int idCelular = 1;
    int idRecarga = 1;

    public void InsertarCelular(Celular objCel) {
        listaCelulares.add(objCel);
    }

    public Celular BuscarCelular(String numero) {
        for (Celular cel : listaCelulares) {
            if (cel.getNumero().equals(numero)) return cel;
        }
        return null;
    }

    public void InsertarRecarga(Recarga objRec) {
        listaRecargas.add(objRec);
    }

    public int getNuevoIdCelular() {
        return idCelular++;
    }

    public int getNuevoIdRecarga() {
        return idRecarga++;
    }
}
