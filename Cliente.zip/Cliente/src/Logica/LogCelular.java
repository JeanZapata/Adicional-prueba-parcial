package Logica;

import Clases.Celular;
import Clases.Recarga;
import java.util.ArrayList;

public class LogCelular {

    // listas para simular la base de datos
    ArrayList<Celular> listaCelulares = new ArrayList<>();
    ArrayList<Recarga> listaRecargas = new ArrayList<>();

    // contadores para simular autoincremento
    int idCelular = 1;
    int idRecarga = 1;

    public void InsertarCelular(String numero, int estado) {
        Celular objCel = new Celular(idCelular++, numero, estado);
        listaCelulares.add(objCel);
    }

    public Celular BuscarCelular(String numero) {
        for (Celular cel : listaCelulares) {
            if (cel.getNumero().equals(numero)) {
                return cel;
            }
        }
        return null;
    }

    public String RealizarRecarga(String numero, int valor, double porcentajeSaldo) {
        Celular cel = BuscarCelular(numero);
        if (cel == null || cel.getEstado() == 0) {
            return "Celular no válido o inactivo";
        }

        int saldo = (int) (valor * porcentajeSaldo);
        int megas = (int) ((valor - saldo) * 5);

        cel.agregarSaldo(saldo);
        cel.agregarMegas(megas);

        listaRecargas.add(new Recarga(idRecarga++, valor, saldo, megas));

        return "Recarga realizada con éxito.";
    }

    public String RecargarDosTercioUnTercio(String numero, int valor) {
        return RealizarRecarga(numero, valor, 2.0 / 3);
    }
}
