
package Clases;

public class vehiculo {
    int idveh;
    String placa;
    String marca;
    String estado;
    int idprop;

    public vehiculo() {
    }

    public int getIdveh() {
        return idveh;
    }

    public void setIdveh(int idveh) {
        this.idveh = idveh;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIdprop() {
        return idprop;
    }

    public void setIdprop(int idprop) {
        this.idprop = idprop;
    }
    
    
}
