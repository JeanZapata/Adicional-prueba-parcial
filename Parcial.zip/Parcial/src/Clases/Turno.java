
package Clases;

import java.util.ArrayList;

public class Turno {
    int idturn;
    String anden;
    String dia;
    String hora;
    int idprop;

    public Turno() {
    }

    public int getIdturn() {
        return idturn;
    }

    public void setIdturn(int idturn) {
        this.idturn = idturn;
    }

    public String getAnden() {
        return anden;
    }

    public void setAnden(String anden) {
        this.anden = anden;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public int getIdprop() {
        return idprop;
    }

    public void setIdprop(int idprop) {
        this.idprop = idprop;
    }
    
    
    
}
