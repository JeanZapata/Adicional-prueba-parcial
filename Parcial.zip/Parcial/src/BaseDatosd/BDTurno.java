
package BaseDatosd;

import Clases.Propietario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Acer
 */
public class BDTurno {
    
    Conexiones BLcon = new Conexiones();

    
    public int InsertarTurno(Propietario objProp) throws ClassNotFoundException, SQLException{
        String Sentencia="insert into turno (anden,dia,hora,idprop) "
                + "values (?,?,?,?)";
        PreparedStatement ps=BLcon.getConnection().prepareStatement(Sentencia);
        ps.setString(1, objProp.getTurno().get(0).getAnden());
        ps.setString(2, objProp.getTurno().get(0).getDia());
        ps.setString(3, objProp.getTurno().get(0).getHora());
        ps.setInt(4, objProp.getIdprop());
        
        return ps.executeUpdate();
    }
    
    public ResultSet BuscarTurno(Propietario objProp) throws ClassNotFoundException, SQLException{
        String Sentencia="Select * from turno where idprop=?";
        PreparedStatement ps=BLcon.getConnection().prepareStatement(Sentencia);
        ps.setInt(1, objProp.getIdprop());
        
        return ps.executeQuery();
    }
}


