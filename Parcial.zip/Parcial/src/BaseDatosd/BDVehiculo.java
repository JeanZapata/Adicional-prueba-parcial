package BaseDatosd;

import Clases.Propietario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class BDVehiculo {
    
    Conexiones BLcon = new Conexiones();
    
    public int InsertarVehiculo(Propietario objProp) throws ClassNotFoundException, SQLException{
        String Sentencia = "insert into vehiculo (placa, marca, estado, idprop) values (?, ?, ?, ?)";
        PreparedStatement ps = BLcon.getConnection().prepareStatement(Sentencia);
        ps.setString(1, objProp.getVehiculo().get(0).getPlaca());
        ps.setString(2, objProp.getVehiculo().get(0).getMarca());
        ps.setString(3, objProp.getVehiculo().get(0).getEstado());
        ps.setInt(4, objProp.getIdprop());
        
        return ps.executeUpdate();
    }
    
    public ResultSet BuscarVehiculo(Propietario objProp) throws ClassNotFoundException, SQLException{
        String Sentencia = "SELECT * FROM vehiculo WHERE idprop = ?";
        PreparedStatement ps = BLcon.getConnection().prepareStatement(Sentencia);
        ps.setInt(1, objProp.getIdprop());
        
        return ps.executeQuery();
    }
}
