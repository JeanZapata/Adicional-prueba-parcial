/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BaseDatosd;

import Clases.Propietario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Acer
 */
public class BDPropietario {

    Conexiones BLcon = new Conexiones();

   public int InsertarPropietario(Propietario objProp) throws ClassNotFoundException, SQLException{
        String Sentencia="insert into propietario (cedula,nombre,apellido)"
                + "values (?,?,?)";
        PreparedStatement ps=BLcon.getConnection().prepareStatement(Sentencia);
        ps.setString(1, objProp.getCedula());
        ps.setString(2, objProp.getNombre());
        ps.setString(3, objProp.getApellido());
        
        return ps.executeUpdate();
    }
    
    public ResultSet BuscarCedula(Propietario objProp) throws ClassNotFoundException, SQLException{
        String Sentencia="Select * from propietario where cedula=?";
        PreparedStatement ps=BLcon.getConnection().prepareStatement(Sentencia);
        ps.setString(1, objProp.getCedula());
        
        return ps.executeQuery();
    }
    
}
