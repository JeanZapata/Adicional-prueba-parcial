package Logica;

import BaseDatosd.BDPropietario;
import Clases.Propietario;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import BaseDatosd.BDVehiculo;
import BaseDatosd.BDTurno;

public class LogPropietario {

    BDPropietario objBDPropietario = new BDPropietario();
    LogVehiculo objLogVehiculo = new LogVehiculo();
    LogTurno objLogTurno = new LogTurno();

    // Método para insertar un nuevo propietario en la base de datos
    public void insertarPropietario(Propietario objPropietario) throws ClassNotFoundException, SQLException {
        objBDPropietario.InsertarPropietario(objPropietario);
        ResultSet rs = objBDPropietario.BuscarCedula(objPropietario);
        
        if (rs != null) {
            while (rs.next()) {
                objPropietario.setIdprop(rs.getInt(1));
            }
        }

        objLogVehiculo.InsertarVehiculo(objPropietario);
        objLogTurno.InsertarTurno(objPropietario);

        if (rs != null) {
            rs.close();
        }
    }

    public void buscarPropietario(Propietario objPropietario) throws ClassNotFoundException, SQLException {
        ResultSet rs = objBDPropietario.BuscarCedula(objPropietario);
        
        if (rs != null) {
            while (rs.next()) {
                objPropietario.setIdprop(rs.getInt(1));
                objPropietario.setCedula(rs.getString(2));
                objPropietario.setNombre(rs.getString(3));
                objPropietario.setApellido(rs.getString(4));
            }
        }

        if (objPropietario.getVehiculo() == null) {
            objPropietario.setVehiculo(new ArrayList<>());
        }
        objLogVehiculo.BuscarVehiculo(objPropietario);

        if (objPropietario.getTurno() == null) {
            objPropietario.setTurno(new ArrayList<>());
        }
        // Buscamos los turnos del propietario
        objLogTurno.BuscarTurno(objPropietario);

        if (rs != null) {
            rs.close();
        }
    }
}
