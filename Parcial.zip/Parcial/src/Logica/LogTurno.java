
package Logica;

import BaseDatosd.BDTurno;
import Clases.Propietario;
import Clases.Turno;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LogTurno {
    
     BDTurno objBDTurn= new BDTurno();
    
    public void BuscarTurno(Propietario objProp) throws ClassNotFoundException, SQLException{
        ResultSet rs=objBDTurn.BuscarTurno(objProp);
        while(rs.next()){
            
            Turno turn= new Turno();
            
            turn.setIdturn(rs.getInt(1));
            turn.setAnden(rs.getString(2));
            turn.setDia(rs.getString(3));
            turn.setHora(rs.getString(4));
            turn.setIdprop(rs.getInt(5));
            
            objProp.getTurno().add(turn);
        }
        rs.close();
    }
    
    
}

    
      
