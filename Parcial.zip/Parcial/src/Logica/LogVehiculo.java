
package Logica;

import BaseDatosd.BDTurno;
import BaseDatosd.BDVehiculo;
import Clases.Propietario;
import Clases.Turno;
import Clases.vehiculo;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LogVehiculo {
    
     BDVehiculo objBDVeh= new BDVehiculo();
    
    public void BuscarVehiculo(Propietario objProp) throws ClassNotFoundException, SQLException{
        ResultSet rs=objBDVeh.BuscarVehiculo(objProp);
        while(rs.next()){
           
            vehiculo veh= new vehiculo();
            
            veh.setIdveh(rs.getInt(1));
            veh.setPlaca(rs.getString(2));
            veh.setMarca(rs.getString(3));
            veh.setEstado(rs.getString(4));
            veh.setIdprop(objProp.getIdprop());
            
            objProp.getVehiculo().add(veh);
            
        }
        rs.close();
    }
    
}
    
